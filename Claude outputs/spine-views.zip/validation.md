# Spine validation

## Counts

| Check | Value | Expected | Result |
|---|---|---|---|
| Cervical vertebrae | 7 | 7 | PASS |
| Thoracic vertebrae | 12 | 12 | PASS |
| Lumbar vertebrae | 5 | 5 | PASS |
| Intervertebral discs | 23 | 23 | PASS |
| Disc C1–C2 | absent | absent | PASS |
| First / last disc | C2–C3 disc … L5–S1 disc | C2–C3 … L5–S1 | PASS |
| Sacrum (fused unit), coccyx | true, true | true, true | PASS |
| Unique IDs | 49 / 49 | 49 | PASS |

## Sagittal alignment (side view)

| Parameter | Model | Healthy adult reference | Result |
|---|---|---|---|
| Cervical lordosis C2–C7 (Cobb) | 18.5° | ≈ 10–25° | PASS |
| Atlas ring vs axis (C1–C2) | 22.0° extension | ≈ 20–30° | PASS |
| T1 slope | 24.9° | ≈ 25 ± 8° | PASS |
| Thoracic kyphosis T4–T12 | 36.2° | ≈ 37 ± 11° | PASS |
| Thoracic kyphosis T1–T12 | 42.4° | ≈ 40–50° | PASS |
| Thoracolumbar T11–L1 | 1.5° kyphosis | ≈ 0–10° | PASS |
| Lumbar lordosis L1–S1 | 57.5° | ≈ 57 ± 11° (women slightly more) | PASS |
| Sacral slope / pelvic tilt / incidence | 41° / 12° / 53° | ≈ 40 / 12 / 52° | PASS |
| C7 plumb line vs S1 posterior corner (SVA) | 20 mm | within ± 25 mm | PASS |
| C2–C7 SVA | 27 mm | ≈ 15–30 mm | PASS |
| Midline offset of every element (front/back) | 0.00 mm | 0 (no scoliosis) | PASS |
| Left–right symmetry of every shape | 0.000 mm | 0 | PASS |

## Lengths and landmarks (figure height 1830 mm)

| Measure | Model | Reference | Result |
|---|---|---|---|
| Cervical (atlas top → C7–T1 disc) | 14.4 cm | ≈ 12.5 cm × stature scale ≈ 13 cm | PASS |
| Thoracic (T1 → T12–L1 disc) | 31.8 cm | ≈ 29–32 cm (Gray scaled ≈ 29; landmark fit ≈ 32) | PASS |
| Lumbar (L1 → L5–S1 disc) | 18.0 cm | ≈ 18 cm × scale ≈ 19 cm | PASS |
| Sacrum + coccyx (along the curve) | 13.4 cm | ≈ 10 + 3.5 cm (female) | PASS |
| Whole column | 77.5 cm = 0.423 × stature | ≈ 0.40 × stature | PASS |
| Discs share of the C2–S1 column | 25 % | ≈ 20–25 % | PASS |
| C7 spinous tip (cervicale) | 1546 mm = 0.845 H | ≈ 0.845–0.850 H (ANSUR II women) | PASS |
| L4–L5 disc height above floor | 1085 mm = 0.593 H | iliac crest ≈ 0.593 H | PASS |
| Atlas top below the vertex | 156 mm | ≈ 140–165 mm left for the skull | PASS |
| S1 plate centre above hip axis | 93 mm (hip at 952 mm) | ≈ 90–100 mm | PASS |
| Coccyx tip above floor | 927 mm | ≈ ischial level | PASS |

## Contacts

| Check | Value | Expected | Result |
|---|---|---|---|
| Disc ↔ adjacent end plates (largest gap) | 0.73 mm | flush (under 1 px = 1 mm) | PASS |
| Deepest bone overlap between neighbouring bones | 1.5 mm (T2/T3) | ≤ 1.5 mm (sub-pixel; cartilage contact) | PASS |
| Neighbouring bones apart by more than a joint space (> 3.5 mm) | none | none | PASS |

## View consistency

| View | Frame | Top row | Bottom row | Colours | Result |
|---|---|---|---|---|---|
| Front | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Front 3/4 right | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Right side | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Back 3/4 right | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Back | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Back 3/4 left | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Left side | 800×800 | 28 | 774 | opaque or clear only | PASS |
| Front 3/4 left | 800×800 | 28 | 774 | opaque or clear only | PASS |
